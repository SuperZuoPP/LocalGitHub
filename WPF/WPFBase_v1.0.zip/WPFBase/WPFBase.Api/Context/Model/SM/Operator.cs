﻿namespace WPFBase.Api.Context.Model.SM
{
    public class Operator:EntityBase
    {

        public string UserCode { get; set; }

        public string UserNumber { get; set; }

        public string UserName { get; set; }

        public string Password { get; set; }

        public int Status { get; set; } 
    }
}
