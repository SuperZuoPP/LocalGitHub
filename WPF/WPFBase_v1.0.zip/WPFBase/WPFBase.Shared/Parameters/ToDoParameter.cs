﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WPFBase.Shared.Parameters
{
    public class ToDoParameter : QueryParameter
    {
        public int? Status { get; set; }
    }
}