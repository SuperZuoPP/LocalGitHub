﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFBase.Common
{
    public interface IConfigureService
    {
        void Configure();
    }
}
